import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useMemo, useState } from 'react'

const img = (name) => `/images/${name}`

const NAV = [
  { id: 'home', label: 'Home' },
  { id: 'product', label: 'VEYRONIS-01' },
  { id: 'engineering', label: 'Engineering' },
  { id: 'operator', label: 'Operator AI' },
  { id: 'store', label: 'Private Access' },
  { id: 'company', label: 'Company' },
]

const PAGE_VARIANTS = {
  initial: { opacity: 0, y: 24, filter: 'blur(10px)' },
  animate: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] } },
  exit: { opacity: 0, y: -18, filter: 'blur(8px)', transition: { duration: 0.28 } },
}

const engineeringModules = [
  {
    title: 'Cranial Sensor Shell',
    img: img('face-detail.webp'),
    tag: 'Face / Sensor Mask',
    copy: 'A black-titanium facial shell with knife-slit optic housing, angular brow armour and layered sensor protection. Built to make VEYRONIS-01 feel controlled, alert and impossible to ignore.',
  },
  {
    title: 'Cervical Drive Stack',
    img: img('neck-two.webp'),
    tag: 'Neck Architecture',
    copy: 'Exposed mechanical tendons, cable rails and reinforced hydraulic channels create the signature lowered-head posture and smooth controlled head movement.',
  },
  {
    title: 'Throat Command Core',
    img: img('throat.webp'),
    tag: 'Voice / Command Channel',
    copy: 'A dense throat assembly with gold-toned internal routing, braided black conduits and diagnostic points designed around future spoken command interaction.',
  },
  {
    title: 'Thoracic Power Core',
    img: img('chest-core.webp'),
    tag: 'Chest / Central Core',
    copy: 'A central illuminated chest module surrounded by rib-like graphite armour, protective plates and compact internal routing for the visual language of power and control.',
  },
  {
    title: 'Shoulder Actuator Frame',
    img: img('shoulder-one.webp'),
    tag: 'Shoulder / Load System',
    copy: 'Heavy shoulder housings with circular actuator forms, glossy graphite armour and layered mechanisms that give the frame its powerful upper-body silhouette.',
  },
  {
    title: 'Precision Manipulator Hand',
    img: img('hand-two.webp'),
    tag: 'Hand / Fine Control',
    copy: 'Multi-joint mechanical fingers, illuminated plates and exposed actuator paths designed to communicate precision, grip control and high-value manipulation.',
  },
]

const capabilities = [
  ['Mission Control', 'Tracks goals, priorities and active objectives so the system can guide the next move instead of waiting passively.'],
  ['Visual Analysis', 'Prepared for future image, file and environment understanding through a vision-ready operator interface.'],
  ['Voice Interaction', 'Designed around fast command response, direct guidance and future spoken execution layers.'],
  ['Task Support', 'Organises applications, projects, notes, workflows and daily action steps through a command-center structure.'],
  ['Business Monitoring', 'Future-ready for dashboards, launch tracking, product updates, client work and operational alerts.'],
  ['Personal Operator Logic', 'Built to challenge drift, review progress and push structured action with calm authority.'],
]

const prices = [
  {
    name: 'Access Deposit',
    price: '£499',
    note: 'Priority interest registration',
    items: ['Private launch updates', 'Founder build notes', 'Priority demo invitation', 'Reservation interest record'],
  },
  {
    name: 'Core Operator System',
    price: 'From £24,999',
    note: 'AI command interface concept',
    items: ['Operator dashboard', 'Mission system', 'Voice-ready interface', 'Vision-ready system layer'],
    featured: true,
  },
  {
    name: 'VEYRONIS-01 Concept Unit',
    price: 'From £89,000',
    note: 'Future humanoid platform estimate',
    items: ['Humanoid design consultation', 'Private concept reservation', 'Engineering scope review', 'Premium support channel'],
  },
  {
    name: 'Enterprise Build',
    price: 'From £250,000',
    note: 'Custom robotics/operator programme',
    items: ['Bespoke interface system', 'Automation planning', 'Dedicated technical roadmap', 'Private engineering consultation'],
  },
]

const team = [
  ['Hamza Inayat', 'Founder & Lead Systems Engineer', 'Leads the VEYRONIS concept, operator logic, premium brand system and product direction.'],
  ['Oliver Reed', 'Mechanical Design Engineer', 'Focuses on shoulder architecture, frame language and high-end mechanical form.'],
  ['James Carter', 'Robotics Systems Architect', 'Shapes the system structure, module roadmap and command-ready platform logic.'],
  ['Amelia Brooks', 'Interface & Product Experience Lead', 'Designs the luxury command interface, page motion and premium user flow.'],
  ['Ethan Hayes', 'AI Operations Engineer', 'Builds mission-control workflows, automation logic and task intelligence concepts.'],
  ['Sophia Bennett', 'Brand & Product Strategy Lead', 'Positions VEYRONIS as a dark-luxury robotics system built for private access.'],
]

function App() {
  const [active, setActive] = useState('home')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 1250)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [active])

  const activeLabel = useMemo(() => NAV.find((n) => n.id === active)?.label ?? 'Home', [active])

  return (
    <main className="min-h-screen overflow-hidden bg-vblack text-white selection:bg-gold selection:text-black">
      <BackgroundSystem />
      <AnimatePresence>
        {loading && <Loader />}
      </AnimatePresence>
      <Header active={active} setActive={setActive} activeLabel={activeLabel} />
      <AnimatePresence mode="wait">
        <motion.section key={active} variants={PAGE_VARIANTS} initial="initial" animate="animate" exit="exit" className="relative z-10">
          {active === 'home' && <Home setActive={setActive} />}
          {active === 'product' && <Product />}
          {active === 'engineering' && <Engineering />}
          {active === 'operator' && <OperatorAI />}
          {active === 'store' && <Store />}
          {active === 'company' && <Company />}
        </motion.section>
      </AnimatePresence>
      <Footer setActive={setActive} />
    </main>
  )
}

function Header({ active, setActive, activeLabel }) {
  return (
    <header className="fixed left-0 right-0 top-0 z-50 border-b border-white/10 bg-black/45 backdrop-blur-2xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <button onClick={() => setActive('home')} className="group flex items-center gap-3 text-left">
          <span className="relative flex h-10 w-10 items-center justify-center rounded-full border border-gold/40 bg-gold/10 shadow-gold">
            <span className="absolute h-2 w-2 rounded-full bg-gold shadow-[0_0_20px_rgba(216,181,109,.95)]" />
            <span className="absolute h-8 w-8 animate-ping rounded-full border border-gold/20" />
          </span>
          <span>
            <span className="block text-sm font-semibold tracking-[0.38em] text-white">VEYRONIS</span>
            <span className="block text-[10px] uppercase tracking-[0.28em] text-muted">Systems / {activeLabel}</span>
          </span>
        </button>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <button
              key={item.id}
              onClick={() => setActive(item.id)}
              className={`rounded-full px-4 py-2 text-xs uppercase tracking-[0.18em] transition ${
                active === item.id ? 'bg-white text-black' : 'text-steel hover:bg-white/10 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <button onClick={() => setActive('store')} className="hidden rounded-full border border-gold/40 bg-gold/10 px-5 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-gold shadow-gold transition hover:bg-gold hover:text-black md:block">
          Request Access
        </button>
      </div>
      <div className="flex gap-2 overflow-x-auto border-t border-white/5 px-4 py-2 lg:hidden">
        {NAV.map((item) => (
          <button
            key={item.id}
            onClick={() => setActive(item.id)}
            className={`whitespace-nowrap rounded-full px-3 py-2 text-[10px] uppercase tracking-[0.16em] ${active === item.id ? 'bg-white text-black' : 'bg-white/5 text-steel'}`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  )
}

function Home({ setActive }) {
  return (
    <PageWrap className="pt-28 lg:pt-24">
      <section className="relative min-h-[calc(100vh-6rem)] overflow-hidden rounded-[2rem] border border-white/10 bg-radial-grid shadow-whiteGlow">
        <motion.img
          src={img('hero-face.webp')}
          alt="VEYRONIS-01 close-up face banner"
          className="absolute inset-0 h-full w-full object-cover opacity-70"
          initial={{ scale: 1.08, x: 30 }}
          animate={{ scale: 1, x: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        />
        <div className="absolute inset-0 bg-[linear-gradient(90deg,#030303_0%,rgba(3,3,3,.92)_28%,rgba(3,3,3,.48)_58%,rgba(3,3,3,.18)_100%)]" />
        <div className="absolute inset-0 opacity-40 grid-overlay" />
        <Scanner />
        <div className="relative z-10 grid min-h-[calc(100vh-6rem)] items-center px-6 py-16 md:px-12 lg:grid-cols-[1.05fr_.95fr] lg:px-16">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.8 }}>
            <StatusPill text="PRIVATE ROBOTICS OPERATOR PLATFORM / COMING SOON" />
            <h1 className="mt-8 max-w-4xl text-5xl font-semibold uppercase leading-[0.92] tracking-[-0.06em] text-white md:text-7xl lg:text-8xl">
              VEYRONIS-01
              <span className="block bg-gradient-to-r from-white via-amberline to-gold bg-clip-text text-transparent">Engineered Beyond Chat.</span>
            </h1>
            <p className="mt-7 max-w-2xl text-base leading-8 text-steel md:text-lg">
              A dark-luxury humanoid operator concept by <strong className="text-white">VEYRONIS Systems</strong>, designed for command presence, intelligent assistance, mission control, precision movement and future autonomous support.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <button onClick={() => setActive('store')} className="premium-button">Request Private Access</button>
              <button onClick={() => setActive('engineering')} className="ghost-button">Explore Engineering</button>
            </div>
            <div className="mt-12 grid max-w-2xl grid-cols-3 gap-3">
              <Metric value="18+" label="Month concept roadmap" />
              <Metric value="6" label="Core engineering zones" />
              <Metric value="£499" label="Access deposit from" />
            </div>
          </motion.div>
          <div className="hidden lg:block" />
        </div>
      </section>
      <section className="mt-8 grid gap-4 md:grid-cols-3">
        <FeatureStrip title="Dark Luxury Build" copy="Gloss graphite armour, gold micro accents and cold white illumination." />
        <FeatureStrip title="Operator Logic" copy="Built around missions, dashboards, tasks, command flow and discipline." />
        <FeatureStrip title="Private Access" copy="Premium reservation model for serious buyers and early supporters." />
      </section>
    </PageWrap>
  )
}

function Product() {
  return (
    <PageWrap>
      <PageHero
        eyebrow="VEYRONIS-01 / PRODUCT"
        title="A machine built for presence, precision and command."
        copy="VEYRONIS-01 is presented as a coming-soon humanoid operator platform: a dark-luxury body language system, an intelligent command layer and a visual identity built to feel powerful before it even moves."
        image={img('full-body.webp')}
        imageAlt="Full body VEYRONIS-01 standing product render"
      />
      <section className="mt-10 grid gap-6 lg:grid-cols-3">
        <LargeSpec title="Command Presence" image={img('torso-full.webp')} copy="A broad upper frame, lowered head posture and forward shoulder architecture make VEYRONIS-01 feel dominant without becoming messy or monstrous." />
        <LargeSpec title="Operator Frame" image={img('torso-alt.webp')} copy="Graphite body armour, illuminated linework and exposed mechanical routing create a premium humanoid silhouette for future operator tasks." />
        <LargeSpec title="Controlled Movement" image={img('side-profile-alt.webp')} copy="The side profile shows cable-rich neck architecture and compact head armour, suggesting smooth, calculated and controlled motion." />
      </section>
      <section className="mt-10 rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 md:p-10">
        <div className="grid gap-8 lg:grid-cols-[.8fr_1.2fr] lg:items-center">
          <div>
            <StatusPill text="PRODUCT STORY" />
            <h2 className="mt-6 text-3xl font-semibold uppercase tracking-[-0.04em] md:text-5xl">Built from a private operator idea into a future robotics system.</h2>
          </div>
          <div className="space-y-5 text-steel leading-8">
            <p>
              VEYRONIS began as a private AI operator concept: a system made to organise goals, remember important context, track daily missions and push the next move with calm authority. The visual body of VEYRONIS-01 was then designed around that same idea — not friendly decoration, but presence, discipline and control.
            </p>
            <p>
              The concept roadmap is presented as an <strong className="text-white">18-month design and prototyping programme</strong>: identity, operator interface, memory core, mission logic, vision layer, voice interaction, tools/actions, mechanical body language and premium storefront launch.
            </p>
          </div>
        </div>
      </section>
    </PageWrap>
  )
}

function Engineering() {
  return (
    <PageWrap>
      <section className="grid gap-8 lg:grid-cols-[.9fr_1.1fr] lg:items-end">
        <div>
          <StatusPill text="ENGINEERING LAYERS" />
          <h1 className="mt-6 text-4xl font-semibold uppercase leading-none tracking-[-0.055em] md:text-7xl">Built like a weapon. Controlled like an instrument.</h1>
        </div>
        <p className="text-lg leading-8 text-steel">
          Each close-up image becomes a premium product module: face, throat, neck, chest, shoulder and hand. The website describes VEYRONIS-01 as a layered engineering concept, not just a pretty robot render.
        </p>
      </section>
      <section className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {engineeringModules.map((m, index) => (
          <motion.article
            key={m.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.55, delay: index * 0.05 }}
            className="group overflow-hidden rounded-[1.7rem] border border-white/10 bg-white/[0.035]"
          >
            <div className="relative h-72 overflow-hidden">
              <img src={m.img} alt={m.title} className="h-full w-full object-cover transition duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/10 to-transparent" />
              <span className="absolute left-5 top-5 rounded-full border border-gold/40 bg-black/50 px-3 py-1 text-[10px] uppercase tracking-[0.2em] text-gold backdrop-blur-md">{m.tag}</span>
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-semibold tracking-[-0.04em]">{m.title}</h2>
              <p className="mt-4 text-sm leading-7 text-steel">{m.copy}</p>
            </div>
          </motion.article>
        ))}
      </section>
    </PageWrap>
  )
}

function OperatorAI() {
  return (
    <PageWrap>
      <PageHero
        eyebrow="OPERATOR INTELLIGENCE"
        title="Not just a robot. A command system."
        copy="VEYRONIS is designed around direction: missions, memory, progress review, task support, business monitoring and future autonomous actions. It should guide the next move, not sit there waiting like a normal chatbot."
        image={img('face-angle.webp')}
        imageAlt="Close up VEYRONIS face operator intelligence"
      />
      <section className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {capabilities.map(([title, copy], i) => (
          <motion.div
            key={title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.45, delay: i * 0.04 }}
            className="rounded-[1.5rem] border border-white/10 bg-gradient-to-br from-white/[0.07] to-white/[0.02] p-6"
          >
            <span className="text-xs font-semibold uppercase tracking-[0.28em] text-gold">0{i + 1}</span>
            <h3 className="mt-5 text-2xl font-semibold tracking-[-0.04em]">{title}</h3>
            <p className="mt-3 text-sm leading-7 text-steel">{copy}</p>
          </motion.div>
        ))}
      </section>
      <section className="mt-10 overflow-hidden rounded-[2rem] border border-white/10 bg-black">
        <div className="grid lg:grid-cols-2">
          <div className="p-8 md:p-12">
            <StatusPill text="LIVE COMMAND FEEL" />
            <h2 className="mt-6 text-3xl font-semibold uppercase tracking-[-0.045em] md:text-5xl">It does not wait for chaos. It organises it.</h2>
            <div className="mt-8 space-y-3 font-mono text-sm text-steel">
              <HudLine label="MISSION" value="Build. Track. Execute." />
              <HudLine label="MODE" value="Private operator access" />
              <HudLine label="VISION" value="Image and environment ready" />
              <HudLine label="VOICE" value="Command-response layer" />
              <HudLine label="STATUS" value="Coming soon / consultation only" />
            </div>
          </div>
          <img src={img('side-profile.webp')} alt="VEYRONIS side profile command interface" className="h-full min-h-[460px] w-full object-cover" />
        </div>
      </section>
    </PageWrap>
  )
}

function Store() {
  return (
    <PageWrap>
      <section className="text-center">
        <StatusPill text="PRIVATE ACCESS / PRICING" />
        <h1 className="mx-auto mt-6 max-w-5xl text-4xl font-semibold uppercase leading-none tracking-[-0.055em] md:text-7xl">Premium access for a system that is not built for the crowd.</h1>
        <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-steel">
          VEYRONIS-01 is positioned as a coming-soon private robotics/operator platform. Pricing below is presented as high-end starting guidance for access, concept reservations and custom engineering enquiries.
        </p>
      </section>
      <section className="mt-12 grid gap-5 lg:grid-cols-4">
        {prices.map((p) => (
          <PricingCard key={p.name} {...p} />
        ))}
      </section>
      <section className="mt-10 grid gap-6 rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 md:p-10 lg:grid-cols-[1fr_.8fr] lg:items-center">
        <div>
          <h2 className="text-3xl font-semibold uppercase tracking-[-0.04em] md:text-5xl">Request Private Access</h2>
          <p className="mt-5 leading-8 text-steel">
            This is not a basic checkout experience. VEYRONIS Systems uses a private-access model: clients submit interest, budget range and intended use. The team then reviews fit, scope and consultation requirements.
          </p>
          <p className="mt-4 text-sm leading-7 text-muted">
            Final availability, delivery terms, technical scope and legal/engineering requirements are subject to private consultation. Replace the email before public launch if you register a real domain.
          </p>
        </div>
        <form className="rounded-[1.5rem] border border-gold/20 bg-black/40 p-5 shadow-gold">
          <label className="form-label">Name</label>
          <input className="form-input" placeholder="Private client name" />
          <label className="form-label">Email</label>
          <input className="form-input" placeholder="client@example.com" />
          <label className="form-label">Interest Level</label>
          <select className="form-input">
            <option>Access Deposit</option>
            <option>Core Operator System</option>
            <option>VEYRONIS-01 Concept Unit</option>
            <option>Enterprise Build</option>
          </select>
          <button type="button" className="premium-button mt-5 w-full">Submit Private Request</button>
        </form>
      </section>
    </PageWrap>
  )
}

function Company() {
  return (
    <PageWrap>
      <PageHero
        eyebrow="VEYRONIS SYSTEMS / COMPANY"
        title="A dark-luxury robotics company built around command, discipline and future operators."
        copy="VEYRONIS Systems specialises in premium AI operator interfaces, robotics concept design, humanoid product storytelling, automation workflows, cinematic web experiences and future-ready command systems."
        image={img('neck-one.webp')}
        imageAlt="VEYRONIS neck engineering company story"
      />
      <section className="mt-10 rounded-[2rem] border border-white/10 bg-white/[0.035] p-6 md:p-10">
        <div className="grid gap-8 lg:grid-cols-[.85fr_1.15fr]">
          <div>
            <StatusPill text="FOUNDER STORY" />
            <h2 className="mt-6 text-3xl font-semibold uppercase tracking-[-0.04em] md:text-5xl">Founded by Hamza Inayat.</h2>
          </div>
          <div className="space-y-5 text-steel leading-8">
            <p>
              Hamza Inayat built the VEYRONIS direction around one clear belief: the next generation of AI should feel like a personal operator, not a generic chatbot. The system was shaped to support goals, discipline, applications, business work, daily planning and future automation.
            </p>
            <p>
              The VEYRONIS-01 visual identity took that operator idea and translated it into a machine: lowered head, aggressive face shell, exposed neck systems, powerful shoulder frame, illuminated chest core and precision mechanical hands. Every image is treated like part of a premium engineering story.
            </p>
          </div>
        </div>
      </section>
      <section className="mt-10">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
          <div>
            <StatusPill text="PRIVATE CONCEPT TEAM" />
            <h2 className="mt-5 text-3xl font-semibold uppercase tracking-[-0.04em] md:text-5xl">Engineering & Product Team</h2>
          </div>
          <p className="max-w-xl text-sm leading-7 text-muted">The additional team profiles are fictional placeholders for this premium concept website/demo.</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {team.map(([name, role, bio], i) => (
            <motion.article
              key={name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
              className="rounded-[1.4rem] border border-white/10 bg-gradient-to-br from-white/[0.07] to-white/[0.02] p-6"
            >
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-full border border-gold/30 bg-gold/10 text-sm font-bold text-gold">{name.split(' ').map((n) => n[0]).join('')}</div>
              <h3 className="text-xl font-semibold tracking-[-0.03em]">{name}</h3>
              <p className="mt-1 text-xs uppercase tracking-[0.2em] text-gold">{role}</p>
              <p className="mt-4 text-sm leading-7 text-steel">{bio}</p>
            </motion.article>
          ))}
        </div>
      </section>
      <section className="mt-10 grid gap-5 lg:grid-cols-2">
        <ContactCard title="Contact" lines={['access@veyronissystems.com', 'Private access enquiries only', 'London / Remote concept studio']} />
        <ContactCard title="What We Build" lines={['Premium AI operator interfaces', 'Robotics-inspired product websites', 'Automation and command workflows', 'Cinematic launch systems']} />
      </section>
    </PageWrap>
  )
}

function PageWrap({ children, className = '' }) {
  return <div className={`mx-auto max-w-7xl px-5 pb-16 pt-32 lg:px-8 ${className}`}>{children}</div>
}

function PageHero({ eyebrow, title, copy, image, imageAlt }) {
  return (
    <section className="overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.035]">
      <div className="grid lg:grid-cols-[.9fr_1.1fr]">
        <div className="relative z-10 flex flex-col justify-center p-8 md:p-12 lg:p-14">
          <StatusPill text={eyebrow} />
          <h1 className="mt-7 text-4xl font-semibold uppercase leading-none tracking-[-0.055em] md:text-6xl">{title}</h1>
          <p className="mt-7 text-base leading-8 text-steel md:text-lg">{copy}</p>
        </div>
        <div className="relative min-h-[520px] overflow-hidden">
          <img src={image} alt={imageAlt} className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/10 to-transparent lg:from-black/30" />
          <div className="absolute bottom-6 left-6 rounded-full border border-white/15 bg-black/50 px-4 py-2 text-[10px] uppercase tracking-[0.26em] text-steel backdrop-blur-md">Asset registered / VEYRONIS-01</div>
        </div>
      </div>
    </section>
  )
}

function LargeSpec({ title, image, copy }) {
  return (
    <motion.article whileHover={{ y: -8 }} className="overflow-hidden rounded-[1.7rem] border border-white/10 bg-white/[0.035] transition">
      <div className="h-96 overflow-hidden">
        <img src={image} alt={title} className="h-full w-full object-cover transition duration-700 hover:scale-105" />
      </div>
      <div className="p-6">
        <h3 className="text-2xl font-semibold tracking-[-0.04em]">{title}</h3>
        <p className="mt-3 text-sm leading-7 text-steel">{copy}</p>
      </div>
    </motion.article>
  )
}

function PricingCard({ name, price, note, items, featured }) {
  return (
    <motion.article
      whileHover={{ y: -10, scale: 1.01 }}
      className={`relative rounded-[1.7rem] border p-6 ${featured ? 'border-gold/50 bg-gold/[0.08] shadow-gold' : 'border-white/10 bg-white/[0.035]'}`}
    >
      {featured && <span className="absolute right-5 top-5 rounded-full bg-gold px-3 py-1 text-[10px] font-bold uppercase tracking-[0.18em] text-black">Recommended</span>}
      <h3 className="pr-24 text-2xl font-semibold tracking-[-0.04em]">{name}</h3>
      <p className="mt-2 text-xs uppercase tracking-[0.2em] text-muted">{note}</p>
      <p className="mt-8 text-4xl font-semibold tracking-[-0.06em] text-white">{price}</p>
      <ul className="mt-7 space-y-3 text-sm text-steel">
        {items.map((item) => <li key={item} className="flex gap-3"><span className="mt-1 h-2 w-2 rounded-full bg-gold shadow-gold" />{item}</li>)}
      </ul>
      <button className={`${featured ? 'premium-button' : 'ghost-button'} mt-8 w-full`}>Request Quote</button>
    </motion.article>
  )
}

function FeatureStrip({ title, copy }) {
  return (
    <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.035] p-6">
      <h3 className="text-lg font-semibold tracking-[-0.03em]">{title}</h3>
      <p className="mt-2 text-sm leading-6 text-muted">{copy}</p>
    </div>
  )
}

function Metric({ value, label }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/35 p-4 backdrop-blur-md">
      <p className="text-2xl font-semibold text-gold">{value}</p>
      <p className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted">{label}</p>
    </div>
  )
}

function HudLine({ label, value }) {
  return (
    <div className="flex items-center justify-between gap-5 rounded-xl border border-white/10 bg-white/[0.035] px-4 py-3">
      <span className="text-gold">{label}</span>
      <span className="text-right">{value}</span>
    </div>
  )
}

function ContactCard({ title, lines }) {
  return (
    <div className="rounded-[1.7rem] border border-white/10 bg-white/[0.035] p-7">
      <h3 className="text-2xl font-semibold tracking-[-0.04em]">{title}</h3>
      <div className="mt-5 space-y-3 text-steel">
        {lines.map((line) => <p key={line}>{line}</p>)}
      </div>
    </div>
  )
}

function StatusPill({ text }) {
  return (
    <div className="inline-flex w-fit items-center gap-3 rounded-full border border-gold/30 bg-gold/10 px-4 py-2 text-[10px] font-semibold uppercase tracking-[0.24em] text-gold">
      <span className="h-2 w-2 rounded-full bg-gold shadow-[0_0_18px_rgba(216,181,109,.9)]" /> {text}
    </div>
  )
}

function Scanner() {
  return <div className="pointer-events-none absolute inset-y-0 left-0 z-[3] w-24 animate-scan bg-gradient-to-r from-transparent via-white/10 to-transparent" />
}

function BackgroundSystem() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 bg-vblack">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_0%,rgba(216,181,109,.13),transparent_28%),radial-gradient(circle_at_90%_10%,rgba(255,255,255,.08),transparent_25%),linear-gradient(180deg,#030303,#07080a,#030303)]" />
      <div className="absolute inset-0 opacity-[0.18] grid-overlay" />
      <div className="absolute left-1/2 top-0 h-[40rem] w-[40rem] -translate-x-1/2 rounded-full bg-gold/5 blur-3xl" />
    </div>
  )
}

function Loader() {
  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.5 } }}
    >
      <div className="text-center">
        <motion.div
          className="mx-auto mb-6 h-16 w-16 rounded-full border border-gold/30 border-t-gold"
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
        />
        <p className="text-xs uppercase tracking-[0.45em] text-gold">VEYRONIS SYSTEM INITIALISING</p>
        <p className="mt-3 text-[10px] uppercase tracking-[0.25em] text-muted">Private operator interface loading</p>
      </div>
    </motion.div>
  )
}

function Footer({ setActive }) {
  return (
    <footer className="relative z-10 border-t border-white/10 px-5 py-10 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.35em]">VEYRONIS Systems</p>
          <p className="mt-2 text-sm text-muted">Premium humanoid operator platform concept. Coming soon.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {NAV.map((n) => <button key={n.id} onClick={() => setActive(n.id)} className="rounded-full border border-white/10 px-4 py-2 text-xs text-steel hover:bg-white hover:text-black">{n.label}</button>)}
        </div>
      </div>
    </footer>
  )
}

export default App
